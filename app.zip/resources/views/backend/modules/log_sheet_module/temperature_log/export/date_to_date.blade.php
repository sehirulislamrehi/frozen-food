<table>
    <tr>
        <th>SId.</th>
        <th>Date & Time</th>
        @for( $i = 0 ; $i < $total_freezer ; $i++ )
        <th>Temp. (°C)</th>
        <th>D. Manual Id</th>
        <th>Type</th>
        @endfor
    </tr>

</table>