<?php

namespace App\Models\DataModule;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Temprature extends Model
{
    use HasFactory;

    protected $table = 'temperature';
}
